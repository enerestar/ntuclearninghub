﻿using Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
namespace ContosoDataAccess
{
    public class CourseStudentDataAccess
    {
        //private string connectionString = "Data Source=DESKTOP-4BSD0GC;Initial Catalog=ContosoConsoleDB;Integrated Security=True";
        private string connectionString = "Server=localhost;Database=hello;User Id=sa;Password=hello123!;";

        public void newCourse(Course course)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand comm = new SqlCommand("INSERT INTO Course (Name) VALUES (@NAME)");
            comm.Parameters.AddWithValue("Name", course.name);
            comm.Connection = conn;
            comm.ExecuteNonQuery();
            conn.Close();
        }

        public List<Course> getCourses()
        {
            List<Course> courses = new List<Course>();
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand comm = new SqlCommand();
            comm.CommandText = "SELECT ID, Name from Course";
            comm.Connection = conn;
            SqlDataReader dr = comm.ExecuteReader();
            while (dr.Read())
            {
                Course course = new Course();
                course.id = Convert.ToInt32(dr["ID"]);
                course.name = dr["Name"].ToString();
                courses.Add(course);
            }
           
            conn.Close();
            return courses;
        }

        public void newStudent(Student student)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand comm = new SqlCommand();
            comm.CommandText = "INSERT INTO Student (CourseName, Name, Marks) VALUES (@CourseName, @Name, @Marks)";
            comm.Parameters.AddWithValue("CourseName", student.courseName);
            comm.Parameters.AddWithValue("Name", student.name);
            comm.Parameters.AddWithValue("Marks", student.marks);
            comm.Connection = conn;
            comm.ExecuteNonQuery();
            conn.Close();
        }

        public List<Student> getStudents()
        {
            List<Student> students = new List<Student>();
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand comm = new SqlCommand();
            comm.CommandText = "SELECT ID, CourseName, Name, Marks FROM Student";
            comm.Connection = conn;
            SqlDataReader dr = comm.ExecuteReader();
            while (dr.Read())
            {
                Student student = new Student();
                student.id = Convert.ToInt32(dr["id"]);
                student.courseName = dr["CourseName"].ToString();
                student.name = dr["Name"].ToString();
                student.marks = Convert.ToInt32(dr["Marks"]);
                students.Add(student);
            }
            conn.Close();
            return students;
        }


        public List<CourseWithStudentCountAndAverageMarks> getCoursesWithStudentCountAndAverageMarks()
        {
            List<CourseWithStudentCountAndAverageMarks> courseWithExtrasList = new List<CourseWithStudentCountAndAverageMarks>();
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand comm = new SqlCommand(@"
                SELECT Course.ID, Course.Name, COUNT(Student.ID) AS StudentCount, SUM(ISNULL(Student.Marks, 0))/Count(*) AS AverageMarks
                FROM Course LEFT OUTER JOIN Student ON Student.CourseName = Course.Name
                GROUP BY Course.ID, Course.Name
            ");
            comm.Connection = conn;
            SqlDataReader dr = comm.ExecuteReader();
            while (dr.Read())
            {
                CourseWithStudentCountAndAverageMarks courseWithExtras = new CourseWithStudentCountAndAverageMarks();
                Course course = new Course();
                course.id = Convert.ToInt32(dr["id"]);
                course.name = dr["Name"].ToString();
                courseWithExtras.course = course;
                courseWithExtras.studentCount = Convert.ToInt32(dr["StudentCount"]);
                courseWithExtras.averageMarks = Convert.ToInt32(dr["AverageMarks"]);
                courseWithExtrasList.Add(courseWithExtras);
            }
            conn.Close();
            return courseWithExtrasList;
        }

    }
}
