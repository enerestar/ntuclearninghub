﻿using System;
using System.Collections.Generic;

namespace Model
{
    public abstract class BaseModel
    {
        public virtual int id { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime LastEdit { get;  set; }
        //
        public abstract bool Validate(); // hlf defined
    }
    
    public class Course : BaseModel // inheritance
    {
        public Course()
        {
        }

        // Name
        private string _name; // variables
        public string name
        {
            get { return _name; }
            set {
                if (value.Length == 0)
                {
                    throw new Exception("Name can not be empty string");
                }
                _name = value;
            }
        }

        public override bool Validate()
        {
            if (name.Length == 0)
            {
                return false;
            }
            return true;
        }
    }
   
    public class Student : BaseModel
    {
        // Name (Student Name)
        private string _name;
        public string name
        {
            get { return _name; }
            set { _name = value; }
        }

        // Marks
        private int _marks;
        public int marks
        {
            get { return _marks; }
            set {
                if (value > 100) // per data input
                {
                    throw new Exception("Marks can not be more than 100");
                }
                if (value < 0) // per data input
                {
                    throw new Exception("Marks can not be less than 100");
                }
                _marks = value; 
            }
        }

        // Course
        private string _courseName;
        public string courseName
        {
            get { return _courseName; }
            set { _courseName = value; }
        }


        public override bool Validate()
        {
            if (courseName.Length == 0)
            {
                return false;
            }
            if (_marks > 100)
            {
                return false;
            }
            if (_marks < 0)
            {
                return false;
            }
            return true;
        }

    }
    
    public class CourseWithStudentCountAndAverageMarks
    {
        public Course course;
        public int studentCount;
        public int averageMarks;
    }
}
