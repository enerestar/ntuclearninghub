﻿using System;
using System.Collections.Generic;
using Model;
using System.Linq;
using ContosoDataAccess;
namespace ContosoUniversity
{
    class Program
    {
        static string mainAction = "A"; // A -- Add , D- Dsiplay , Edit
        static int subAction = 2; // 1 - Add Course , 2 - Add student...

        static void Main(string[] args)
        {
            
            // string -- series CHAR
            while (mainAction != "Q")
            {
                Console.Clear();
                DisplayAllOptions();
                mainAction = Console.ReadLine();
               
                if (mainAction == "A")
                {
                    DisplayAllAddOptions();
                    subAction = Convert.ToInt32(Console.ReadLine());
                    if (subAction == 1)
                    {
                        AddNewCourse();
                    }
                    if (subAction == 2)
                    {
                        AddStudent();
                    }
                }
                if (mainAction == "D")
                {
                    DisplayAllDisplayOptions();
                    subAction = Convert.ToInt32(Console.ReadLine());
                    if (subAction == 3)
                    {
                        DisplayCourse();
                    }
                    if (subAction == 4)
                    {
                        DisplayStudent();
                    }
                }
                if (mainAction == "E")
                {
                    DisplayAllEditAndDelete();
                    subAction = Convert.ToInt32(Console.ReadLine());
                    if (subAction == 5)
                    {
                        EditCourse();
                    }
                    if (subAction == 7)
                    {
                        EditStudent();
                    }
                }
            }
        }

        static void DisplayAllOptions()
        {
            Console.WriteLine("A - Add , D - Display , E - Edit");
            Console.WriteLine("Enter Which  action you want to execute");
        }

        static void DisplayAllAddOptions()
        {
            Console.WriteLine("1 - Add new Course , 2 Add Students");
            Console.WriteLine("Enter Which  action you want to execute");
        }

        static void DisplayAllDisplayOptions()
        {
            Console.WriteLine("3- Display all courses , 4 - Display Al students");
            Console.WriteLine("Enter Which  action you want to execute");
        }

        static void DisplayAllEditAndDelete()
        {
            Console.WriteLine("5,,7 for edit");
            Console.WriteLine("Enter Which  action you want to execute");
        }

        static void AddStudent()
        {
            Console.WriteLine("Enter the course name");
            string courseName = Console.ReadLine();
            Course course = FindCourse(courseName);
            if (course == null)
            {
                Console.WriteLine("No such course exists");
                Console.ReadLine();
                return;
            }
            Student student = new Student();
            student.courseName = courseName;
            Console.WriteLine("Enter student name");
            student.name = Console.ReadLine();
            Console.WriteLine("Enter student marks");
            string marksAsString = Console.ReadLine();
            int marks;
            if (int.TryParse(marksAsString, out marks))
            {
                student.marks = marks;
            }
            else
            {
                Console.WriteLine("Marks should be numeric");
                Console.ReadLine();
                return;
            }

            // make the datacess call
            CourseStudentDataAccess db = new CourseStudentDataAccess();
            try
            {
                db.newStudent(student);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error saving student");
                Console.WriteLine(e.ToString());
            }
            Console.ReadLine();
        }

        static void AddNewCourse()
        {
            Course course = new Course();
            Console.WriteLine("Enter Course name");
            course.name = Console.ReadLine();
            // make the datacess call
            CourseStudentDataAccess db = new CourseStudentDataAccess();
            try
            {
                db.newCourse(course);
            } catch
            {
                Console.WriteLine("Error saving course");
            }
            Console.ReadLine();
        }

        static void DisplayStudent()
        {
            try
            {
                CourseStudentDataAccess db = new CourseStudentDataAccess();
                List<Student> students= db.getStudents();
                foreach (var student in students)
                {
                    Console.WriteLine(
                        "ID: " + student.id + ";  " +
                        "Name: " + student.name + ";  " +
                        "Course Name: " + student.courseName + ";  " +
                        "Marks: " + student.marks
                    );
                }
                Console.ReadLine();
            }
            catch
            {
                Console.WriteLine("Error getting all courses from db");
            }

            Console.WriteLine("This section will Display students");
            Console.ReadLine();
        }

        static void DisplayCourse()
        {
            CourseStudentDataAccess db = new CourseStudentDataAccess();
            var courseWithExtrasList = db.getCoursesWithStudentCountAndAverageMarks();
            foreach (var courseWithExtras in courseWithExtrasList)
            {
                Console.WriteLine(
                    "Id: " + courseWithExtras.course.id + ";  " +
                    "Course Name: " + courseWithExtras.course.name + ";  " +
                    "Total Students: " + courseWithExtras.studentCount + ";  " +
                    "Average Marks: " + courseWithExtras.averageMarks);
            }
            Console.ReadLine();
        }

        static void EditCourse()
        {
            Console.WriteLine("This section will Edit Course");
            Console.ReadLine();
        }

        static void EditStudent()
        {
            Console.WriteLine("This section will edit students");
            Console.ReadLine();
        }

        static Course FindCourse(string courseName)
        {
            CourseStudentDataAccess db = new CourseStudentDataAccess();
            List<Course> courses = db.getCourses();
            foreach (var course in courses)
            {
                if(course.name == courseName)
                {
                    return course;
                }
            }
            return null;
        }

    }

    
}
